package com.smartFarm.project.model.smartFarm;



import lombok.Data;


@Data
public class AuthVo {
	private String user_id;
	 private String user_auth;
}
