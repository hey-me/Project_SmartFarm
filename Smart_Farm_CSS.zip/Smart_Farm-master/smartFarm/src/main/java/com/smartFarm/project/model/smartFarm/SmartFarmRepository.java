package com.smartFarm.project.model.smartFarm;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SmartFarmRepository extends JpaRepository<SmartFarmVo, String>{

}
