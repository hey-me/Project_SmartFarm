package com.smartFarm.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartFarmApplicationTests {

	@Test
	void contextLoads() {
	}

}
