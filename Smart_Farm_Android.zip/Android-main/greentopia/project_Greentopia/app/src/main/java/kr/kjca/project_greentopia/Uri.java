package kr.kjca.project_greentopia;

public class Uri {
    public static String getUri(){
        return "ws://192.168.166.224:80/";
    }

}
