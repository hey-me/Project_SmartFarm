package kr.kjca.project_greentopia;

import android.os.Bundle;

public interface FragmentCallback {

    public void onFragmentSelected(int position, Bundle bundle);

}
